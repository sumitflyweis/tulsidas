const mongoose = require('mongoose');
const objectId = mongoose.Types.ObjectId
const submenuSchema = mongoose.Schema({
      subMenu:[{
        type:String
    }]
})

module.exports = mongoose.model('Submenu', submenuSchema);
