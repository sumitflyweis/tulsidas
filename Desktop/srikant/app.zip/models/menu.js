const mongoose = require("mongoose");
const objectId = mongoose.Types.ObjectId;
const menuSchema = mongoose.Schema({
  menu: {
    type: String,
    require: true,
  },
  subMenu: {
    type: [objectId],
    ref: "Submenu",
  },
});

module.exports = mongoose.model("menu", menuSchema);
