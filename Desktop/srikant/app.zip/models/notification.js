const mongoose = require('mongoose');



const notificationSchema = mongoose.Schema({
    message: {
        type: String, 
        require: true
    }
})


module.exports = mongoose.model('notify', notificationSchema);


