const express = require('express') 
const {} = require('../controllers/admin/attendence')
const { } = require('../controllers/student/attendence')
const {createAttendence,getAllAttendence,updateAttendence,deleteAttendence} = require('../controllers/teacher/attendence')
const course = express.Router()


//ADMIN
// course.get('/getAllcourseByAdmin',getAllcourseByAdmin)

//STUDENT
// course.get('/getallcourseByStudent',getallcourseByStudent)

//TEACHER
course.post('/createAttendence',createAttendence)
// course.get('/getAllAttendence',getAllAttendence)
// course.put('/updateAttendence/:id',updateAttendence)
// course.delete('/deleteAttendence/:id',deleteAttendence)

module.exports =course