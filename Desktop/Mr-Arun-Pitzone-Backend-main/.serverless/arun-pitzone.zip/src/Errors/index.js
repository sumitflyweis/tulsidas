module.exports = {
    AuthError: require('./AuthError'),
    ValidationError: require('./ValidationError.js'),
}